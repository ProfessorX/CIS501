#!/usr/bin/python
import sys
import csv
import pickle

def exit_with_help():
	sys.stderr.write( "Usage : " + sys.argv[0] + " [Options] [Input File] [Output File] \n")
	sys.stderr.write( "Options : \n")
	sys.stderr.write( "\t-s save_filename : save converting parameters to save_filename\n")
	sys.stderr.write( "\t-r restore_filename : restore converting parameters from restore_filename\n")
	sys.exit(0)

def transpose(x):
	return map(lambda x: list(x) , zip(*x))

def convert_to_numerical_with_map(x,dics):
	xt = transpose(x)
	xxt = []
	for i in range(len(xt)):
		dic = dics[i]
		if len(dic) == 0 :
			if len(list(set(xt[i]))) == 1:
				xxt += [[0 for i in range(len(xt[i]))]]
			else :
				xxt += [xt[i]]	
		else :
			xxt += [map(lambda a : dic.has_key(a) and dic[a] or 0, xt[i])]
	return transpose(xxt)



def convert_to_numerical(x):
	xt = transpose(x)
	xxt = []
	dics = []
	for i in range(len(xt)):
		dic = {}
		unique_list = list(set(xt[i]))
		try :
			#Check if it is able to convert to floating point numbers directly
			map(lambda a : float(a),unique_list) 
			xxt += [xt[i]]
			dics.append({}) 
		except :
			for j in range(len(unique_list)):
				dic[unique_list[j]] = j+1
			xxt += [map(lambda a : dic[a], xt[i])]
			dics.append(dic)
	return transpose(xxt),dics

def write_csv(filename,x):
	csvWriter = csv.writer(open(filename, 'wb'))
	for row in x :
		csvWriter.writerow(row)

def read_csv(filename):
	x = []
	csvReader = csv.reader(open(filename, 'rb'))
	for row in csvReader :
		x += [row]
	return x

#Main Program : 
if len(sys.argv) < 2 :
	exit_with_help()

savemapfile = ""
loadmapfile = ""

k = 1
while 1 :
	if sys.argv[k][0] != '-' :
		break

	if sys.argv[k][1] == 's':
		savemapfile = sys.argv[k+1]
	elif sys.argv[k][1] == 'r':
		loadmapfile = sys.argv[k+1]
	else :
		sys.stderr.write('Unknown Option %s\n' % sys.argv[k])
		exit_with_help()
	k = k + 2

infile = sys.argv[k]
outfile = sys.argv[k+1]

if infile == outfile:
	sys.stderr.write('Error : input and output file have the same name')
	exit_with_help()

x = read_csv(infile)
if len(loadmapfile) > 0:
	dics = pickle.load(open(loadmapfile,'rb'))
	xx = convert_to_numerical_with_map(x,dics)
else :
	xx,dics = convert_to_numerical(x)
write_csv(outfile,xx)

if len(savemapfile) > 0:
	pickle.dump(dics,open(savemapfile,'wb'))
