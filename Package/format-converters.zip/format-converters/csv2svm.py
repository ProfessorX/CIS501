#!/usr/bin/python
import sys
from svmutil import *

def exit_with_help():
	sys.stderr.write( "Usage : " + sys.argv[0] + " [Options] [Input File] [Output File] \n")
	sys.stderr.write( "Options : \n")
	sys.stderr.write( "\t-l label column : the column of labels starting from 0 (default 0)\n")
	sys.exit(0)


#Main Program : 
if len(sys.argv) < 2 :
	exit_with_help()

i = 0
k = 1
while 1 :
	if sys.argv[k][0] != '-' :
		break
	if sys.argv[k][1] == 'l':
		i = int(sys.argv[k+1])
	else :
		sys.stderr.write('Unknown Option %s\n' % sys.argv[k])
		exit_with_help()
	k = k + 2

infile = sys.argv[k]
outfile = sys.argv[k+1]

x = csv_read_data(infile)
xt = zip(*x)
lxt = len(xt)
y = xt[i]

xnewt = []
for j in range(lxt):
	if i == j or i+lxt == j:
		continue
	xnewt.append(xt[j])
xnew = zip(*xnewt)

svm_write_problem(outfile,y,xnew)
