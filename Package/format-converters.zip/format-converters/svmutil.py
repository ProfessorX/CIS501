#!/usr/bin/env python

import os
import math

def is_dense(prob_x) :
	if type(prob_x[0]) == type({}):
		return Flase
	else :
		return True
	
def is_sparse(prob_x) :
	if type(prob_x[0]) == type({}):
		return True
	else :
		return False

def convert_to_sparse(prob_x) :
	if is_sparse(prob_x):
		return prob_x
	else :
		prob_x_sparse = []

		l = len(prob_x)
		n = len(prob_x[0])
		for i in range(l):
			xi = {}
			for j in range(n):
				if prob_x[i][j] != 0:
					xi[j+1] = prob_x[i][j]
			prob_x_sparse += [xi]
		return prob_x_sparse

def convert_to_dense(prob_x) :
	if is_sparse(prob_x):
		n = 0
		l = len(prob_x)
		for i in range(l) :
			n = max(max(prob_x[i].keys()),n)
		prob_x_dense = [[0]*n]*l
		for i in range(l) :
			for k in prob_x[i].keys() :
				prob_x_dense[i-1][k] = prob_x[i][k]
		return prob_x_dense
	else :
		return prob_x


def svm_read_problem(data_file_name):
	"""
	svm_read_problem(data_file_name) -> [y, x]

	Read LIBSVM-format data from data_file_name and return labels y
	and data instances x.
	"""
	prob_y = []
	prob_x = []
	for line in open(data_file_name):
		arrs = line.split(None)
		# In case an instance with all zero features
		if ":" not in arrs[0]:
			label = int(arrs[0])
			prob_y += [float(label)]
			features = arrs[1:]
		else :
			features = arrs
		xi = {}
		for e in features:
			ind, val = e.split(":")
			xi[int(ind)] = float(val)
		prob_x += [xi]
	return (prob_y, prob_x)

def svm_write_problem(data_file_name,prob_y,prob_x):
	if is_dense(prob_x) :
		prob_x = convert_to_sparse(prob_x)
	#Check if the file exists
	while os.path.exists(data_file_name):
		option = raw_input("Data `" + data_file_name + "' exists. Do you want to overwrite it? [y/N]")
		if option == "" or option.lower()[0] == "n":
			return
		if option.lower()[0] == "y":
			break

	fout = open(data_file_name,"w")
	
	l = len(prob_y)
	for i in range(l):
		if len(prob_y) > 0:
			if abs(prob_y[i] - math.floor(prob_y[i])) < 1e-12 or abs(prob_y[i] - math.ceil(prob_y[i])) < 1e-12 :
				fout.write(str(int(prob_y[i])) + " ")
			else :
				fout.write(str(prob_y[i]) + " ")
		toprint = []
		for v in sorted(prob_x[i].keys()) :
			toprint.append(str(v) + ":" + str(prob_x[i][v]))
		fout.write(" ".join(toprint) + "\n")

	fout.close()

def csv_read_data(data_file_name):
	prob_x = []
	for line in open(data_file_name):
		arrs = line.split(',')
		xi = map(lambda x : float(x),arrs)
		prob_x += [xi]
	return (prob_x)

def csv_write_data(data_file_name,prob_x):
	#Check if the file exists
	while os.path.exists(data_file_name):
		option = raw_input("Data `" + data_file_name + "' exists. Do you want to overwrite it? [y/N]")
		if option.lower()[0] == "y":
			break
		if option.lower()[0] == "n":
			return

	fout = open(data_file_name,"w")
	
	l = len(prob_x)
	for i in range(l):
		toprint = []
		for v in prob_x[i] :
			toprint.append(str(v))
		fout.write(",".join(toprint) + "\n")
	fout.close()

def csv_read_problem(data_file_name):
	prob_y = []
	prob_x = []
	for line in open(data_file_name):
		arrs = line.split(',')
		prob_y += int(arrs[0])
		xi = map(lambda x : float(x),arrs[1:])
		prob_x += [xi]
	return (prob_y, prob_x)

def csv_write_problem(data_file_name,prob_y,prob_x):
	#Check if the file exists
	while os.path.exists(data_file_name):
		option = raw_input("Data `" + data_file_name + "' exists. Do you want to overwrite it? [y/N]")
		if option == "" or option.lower()[0] == "y":
			break
		if option.lower()[0] == "n":
			return

	fout = open(data_file_name,"w")
	
	l = len(prob_y)
	for i in range(l):
		if len(prob_y) > 0:
			fout.write(str(prob_y[i]) + ",")
		toprint = []
		for v in prob_x[i] :
			toprint.append(str(v))
		fout.write(",".join(toprint) + "\n")

	fout.close()
