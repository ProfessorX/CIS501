function v=sample_code_version
%v=sample_code_version
% Return the sample code version number.

% Isabelle Guyon -- isabelle@clopinet.com -- March 2009

v='Version 1, March 10, 2009';